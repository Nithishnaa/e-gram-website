<?php
if (isset($_POST['submit'])) {
    if (isset($_POST['country']) && isset($_POST['street']) && 
        isset($_POST['landmark'])  && isset($_POST['pincode']) &&
        isset($_POST['state']) && 
        isset($_POST['district']) && isset($_POST['taluk']) &&
        isset($_POST['village']) && isset($_POST['phone'])) {
        
        $country = $_POST['country'];
        $street = $_POST['street'];
        $landmark = $_POST['landmark'];
        $pincode = $_POST['pincode'];
        $state = $_POST['state'];
        $district = $_POST['district']; 
        $taluk = $_POST['taluk'];
        $village = $_POST['village'];
        $phone = $_POST['phone'];
        
        $host = "localhost:3306";
        $dbusername = "jkmmartc_ezhil";
        $dbpassword = "Ezhil@007";
        $dbname = "jkmmartc_freethinkers";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
        if ($conn->connect_error) {
            die('Could not connect to the database.');
        }
        else {
            $SELECT = "SELECT phone FROM loader WHERE phone = ?";
            $INSERT = "INSERT INTO loader(country, street, landmark, pincode, state, district, taluk, village, phone) values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($SELECT);
            $stmt->bind_param("i", $phone);
            $stmt->execute();
            $stmt->bind_result($resultphone);
            $stmt->store_result();
            $stmt->fetch();
            $rnum = $stmt->num_rows;
            if ($rnum == 0) {
                $stmt->close();
                $stmt = $conn->prepare($INSERT);
                $stmt->bind_param("sssissssi",$country, $street , $landmark , $pincode ,  $state, $district, $taluk, $village, $phone);
                echo "<script> location.href='document.html'; </script>";
                if ($stmt->execute()) {
                    echo "New record inserted sucessfully.";
                }
                else {
                    echo $stmt->error;
                }
            }
            else {
                echo "Someone already registers using this phone.";
            }
            $stmt->close();
            $conn->close();
        }
    }
    else {
        echo "All field are required.";
        die();
    }
}
else {
    echo "Submit button is not set";
}
?>